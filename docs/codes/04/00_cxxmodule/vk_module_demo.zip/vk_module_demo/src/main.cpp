import std;
import vulkan_hpp;

int main() {
    const vk::raii::Context ctx; // 初始化上下文

    constexpr vk::ApplicationInfo app_info = {
        "My App", 1,
        "My Engine", 1,
        vk::makeApiVersion(1, 4, 0, 0)
    };
    const vk::InstanceCreateInfo create_info{ {}, &app_info };
    const vk::raii::Instance instance = ctx.createInstance(create_info);

    std::println("Physical Device: ");
    for (const auto physicalDevices = instance.enumeratePhysicalDevices();
        const auto& physicalDevice : physicalDevices
    ) {
        std::println("\t{}", std::string_view{ physicalDevice.getProperties().deviceName });
    }
}