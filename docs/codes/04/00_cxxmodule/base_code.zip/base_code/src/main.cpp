import std;

int main() {
    std::println("Hello, Module!");
}
